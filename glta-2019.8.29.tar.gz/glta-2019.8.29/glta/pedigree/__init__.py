from glta.pedigree.process_pedigree import *
