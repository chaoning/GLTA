from glta.process_plink.process_plink import *
