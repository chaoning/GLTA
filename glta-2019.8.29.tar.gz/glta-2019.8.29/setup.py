from setuptools import setup, find_packages

setup(
    name='glta',
    version='2019.8.29',
    description='Genomic Longitudinal Trait Analysis Tool',
    author='Ning Chao',
    author_email='ningchao91@gmail.com',
    packages=find_packages(),
    url="https://github.com/chaoning/GLTA",
    include_package_data = True,
)
